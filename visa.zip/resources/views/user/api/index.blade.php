<div class="page-content">
    <div class="container-fluid">
        <!-- Main Card -->
        <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center" style="background-color: #c6d3e0;">
                    <h5 class="card-title mb-0">API Management</h5>
                    <button class="btn btn-sm btn-outline-primary" data-toggle="modal" data-target="#depositModal">API Generate</button>
                </div>
                <div class="card-body">
                    <div class="row">
                            <div class="table-responsive">
                                <table id="cardsTable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                                <tr class="text-center">
                                                    <th>Sr#</th>
                                                    <th>Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr class="text-center">
                                                    <td>1</td>
                                                    <td>2</td
                                                <tr>
                                            </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>
        </div>

        
           
        </div>
        </div>
</div>


    