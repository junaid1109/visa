@include('user/layouts/header')

@include('user/layouts/sidebar')

@include($content)

@include('user/layouts/footer')
