        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="text-sm-right d-none d-sm-block">
                            Copyright © 2025 All Rights Reserved <a href="https://visa.build/" target="_blank">Visa.build</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>

<div class="rightbar-overlay"></div>

<script src="{{asset('admin_assets/libs/jquery/jquery.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/metismenu/metisMenu.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/simplebar/simplebar.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/node-waves/waves.min.js')}}"></script>

<script src="{{asset('admin_assets/libs/apexcharts/apexcharts.min.js')}}"></script>

<script src="{{asset('admin_assets/js/pages/datatables.init.js')}}"></script>

<script src="{{asset('admin_assets/js/pages/dashboard.init.js')}}"></script>

<script src="{{asset('admin_assets/js/app.js')}}"></script>
@stack('scripts')

</body>
</html>