<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>

<?php if(Session::has('unsuccess')): ?>

    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo e(Session::get('unsuccess')); ?>

    </div>
<?php endif; ?>


<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        setTimeout(function(){
            $(".alert").alert('close');
        }, 2000);
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\project\FastPays-New\visa\resources\views/layouts/alert-msg.blade.php ENDPATH**/ ?>