        <footer class="footer">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <script>document.write(new Date().getFullYear())</script> © Udema.
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="text-sm-right d-none d-sm-block">
                                            Design & Develop by KreateQ.com
                                        </div>
                                    </div>
                                </div>
                            </div>
        </footer>
    </div>
</div>

<div class="rightbar-overlay"></div>

<script src="<?php echo e(asset('admin_assets/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/pages/dashboard.init.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/app.js')); ?>"></script>

</body>
</html><?php /**PATH D:\Xampp\htdocs\shades\external\file\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>